// Core application types
export type TabId = 
  | 'dashboard' 
  | 'analysis' 
  | 'data' 
  | 'workflows' 
  | 'code' 
  | 'charts' 
  | 'files' 
  | 'security' 
  | 'settings';

export type ThemeMode = 'light' | 'dark';

export type NavigationMode = 'full' | 'collapsed';

// Data object types
export type DataObjectType = 'database' | 'schema' | 'table' | 'view' | 'report' | 'dataset';

export type DataObjectStatus = 'active' | 'deprecated' | 'archived' | 'healthy' | 'warning' | 'error' | 'critical';

export type DataClassification = 'public' | 'internal' | 'confidential' | 'restricted';

export type TrendDirection = 'up' | 'down' | 'stable';

export type Region = 'Americas' | 'EMEA' | 'APAC' | 'Global';

export type Severity = 'low' | 'medium' | 'high' | 'critical';

export type IssueStatus = 'open' | 'investigating' | 'resolved' | 'closed';

export type QualityCategory = 'completeness' | 'accuracy' | 'consistency' | 'validity' | 'uniqueness' | 'timeliness';

export type RuleType = 'validation' | 'constraint' | 'format' | 'range' | 'relationship';

export type RuleStatus = 'active' | 'inactive' | 'failed' | 'pending';

export type ActivityType = 'query' | 'pipeline' | 'data' | 'analysis' | 'import' | 'export';

export type ActivityStatus = 'completed' | 'running' | 'failed' | 'pending' | 'cancelled';

// Data interfaces
export interface BaseDataObject {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
  lastModified: string;
  owner: string;
  department: string;
  tags: string[];
}

export interface DataObject extends BaseDataObject {
  type: DataObjectType;
  status: DataObjectStatus;
  size: string;
  rowCount: string;
  region: Region;
  classification: DataClassification;
  quality?: number;
  popularity?: number;
  rating?: number;
  usage?: string;
  schema?: string;
  children?: number;
}

export interface DataSource extends DataObject {
  country: string;
  ytdReturn: string;
  p11mEps: string;
  divYield: string;
  mktCap: string;
  volume: string;
  price: string;
  dailyPerformance: string;
  trend: TrendDirection;
  chart: number[];
}

export interface DataMetric {
  id: string;
  label: string;
  value: string;
  change: string;
  trend: TrendDirection;
  status: DataObjectStatus;
  description?: string;
  unit?: string;
  target?: string;
}

export interface QualityMetric {
  id: string;
  name: string;
  category: QualityCategory;
  score: number;
  trend: TrendDirection;
  change: string;
  status: DataObjectStatus;
  lastChecked: string;
  description: string;
  threshold?: number;
  target?: number;
}

export interface DataIssue {
  id: string;
  severity: Severity;
  type: string;
  table: string;
  schema: string;
  database?: string;
  description: string;
  affectedRows: number;
  detectedAt: string;
  status: IssueStatus;
  assignee?: string;
  resolution?: string;
  resolvedAt?: string;
  priority?: number;
  impact?: string;
}

export interface QualityRule {
  id: string;
  name: string;
  type: RuleType;
  table: string;
  column: string;
  condition: string;
  status: RuleStatus;
  lastRun: string;
  passRate: number;
  description?: string;
  threshold?: number;
  enabled: boolean;
  schedule?: string;
}

export interface RecentActivity {
  id: string;
  type: ActivityType;
  title: string;
  description: string;
  timestamp: string;
  status: ActivityStatus;
  user: string;
  duration?: string;
  details?: Record<string, any>;
}

export interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  route: TabId;
  badge?: string;
  enabled?: boolean;
  permissions?: string[];
}

export interface NavigationItem {
  id: TabId;
  label: string;
  icon: string;
  badge?: string | number;
  description: string;
  enabled?: boolean;
  permissions?: string[];
}

export interface SystemMetric {
  id: string;
  label: string;
  value: string;
  status: DataObjectStatus;
  unit?: string;
  threshold?: number;
  description?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar?: string;
  permissions: string[];
  department: string;
  lastLogin?: string;
  preferences?: UserPreferences;
}

export interface UserPreferences {
  theme: ThemeMode;
  sidebarCollapsed: boolean;
  defaultTimeframe: string;
  notifications: NotificationSettings;
  dashboard: DashboardSettings;
}

export interface NotificationSettings {
  email: boolean;
  inApp: boolean;
  dataQuality: boolean;
  systemAlerts: boolean;
  digest: 'daily' | 'weekly' | 'monthly' | 'none';
}

export interface DashboardSettings {
  autoRefresh: boolean;
  refreshInterval: number;
  defaultView: string;
  widgets: string[];
}

// Component prop types
export interface NavigationProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

export interface ThemeProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export interface SearchProps {
  query: string;
  onQueryChange: (query: string) => void;
  placeholder?: string;
  debounceMs?: number;
}

export interface FilterProps {
  filters: Record<string, any>;
  onFiltersChange: (filters: Record<string, any>) => void;
}

export interface PaginationProps {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}

export interface SortProps {
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  onSortChange: (field: string, order: 'asc' | 'desc') => void;
}

// API types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: string;
  requestId: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, any>;
  timestamp: string;
  requestId: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// Event types
export interface NavigationEvent {
  type: 'navigate';
  detail: TabId;
}

export interface ErrorEvent {
  type: 'error';
  error: Error;
  errorInfo?: React.ErrorInfo;
  context?: string;
  timestamp: string;
}

export interface LogEvent {
  level: 'debug' | 'info' | 'warn' | 'error';
  message: string;
  context?: string;
  data?: Record<string, any>;
  timestamp: string;
  requestId?: string;
}

// Configuration types
export interface AppConfig {
  apiBaseUrl: string;
  wsUrl: string;
  features: FeatureFlags;
  monitoring: MonitoringConfig;
  performance: PerformanceConfig;
}

export interface FeatureFlags {
  realTimeUpdates: boolean;
  advancedAnalytics: boolean;
  dataQualityMonitoring: boolean;
  workflowEditor: boolean;
  collaboration: boolean;
  exportFeatures: boolean;
}

export interface MonitoringConfig {
  enabled: boolean;
  endpoint: string;
  sampleRate: number;
  errorReporting: boolean;
  performanceTracking: boolean;
}

export interface PerformanceConfig {
  virtualization: boolean;
  lazyLoading: boolean;
  caching: boolean;
  debounceMs: number;
  pageSize: number;
}

// State management types
export interface AppState {
  user: User | null;
  theme: ThemeMode;
  navigation: NavigationState;
  data: DataState;
  ui: UIState;
  errors: ErrorState;
}

export interface NavigationState {
  activeTab: TabId;
  sidebarCollapsed: boolean;
  breadcrumbs: Breadcrumb[];
  history: TabId[];
}

export interface DataState {
  objects: DataObject[];
  metrics: DataMetric[];
  issues: DataIssue[];
  activities: RecentActivity[];
  loading: boolean;
  lastUpdated: string;
}

export interface UIState {
  modals: Record<string, boolean>;
  notifications: Notification[];
  loading: Record<string, boolean>;
  selectedItems: string[];
}

export interface ErrorState {
  errors: ErrorEvent[];
  lastError: ErrorEvent | null;
  errorBoundary: boolean;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actions?: NotificationAction[];
}

export interface NotificationAction {
  id: string;
  label: string;
  action: () => void;
  variant?: 'primary' | 'secondary' | 'destructive';
}

export interface Breadcrumb {
  id: string;
  label: string;
  path: string;
  icon?: string;
}

// Hook types
export interface UseApiOptions {
  retry?: number;
  timeout?: number;
  cache?: boolean;
  debounce?: number;
}

export interface UseApiResult<T> {
  data: T | null;
  loading: boolean;
  error: ApiError | null;
  refetch: () => Promise<void>;
  mutate: (data: T) => void;
}

// Utility types
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

export type OptionalFields<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type WithTimestamps<T> = T & {
  createdAt: string;
  updatedAt: string;
};

export type WithId<T> = T & {
  id: string;
};

// Type guards
export const isDataObject = (obj: any): obj is DataObject => {
  return obj && typeof obj === 'object' && 'id' in obj && 'type' in obj;
};

export const isApiError = (error: any): error is ApiError => {
  return error && typeof error === 'object' && 'code' in error && 'message' in error;
};

export const isValidTabId = (tab: string): tab is TabId => {
  const validTabs: TabId[] = ['dashboard', 'analysis', 'data', 'workflows', 'code', 'charts', 'files', 'security', 'settings'];
  return validTabs.includes(tab as TabId);
};