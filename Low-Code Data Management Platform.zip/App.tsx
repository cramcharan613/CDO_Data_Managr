import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Home } from './components/Home';
import { Dashboard } from './components/Dashboard';
import { DataGrid } from './components/DataGrid';
import { FlowEditor } from './components/FlowEditor';
import { CodeEditor } from './components/CodeEditor';
import { Settings } from './components/Settings';
import { DataAnalysis } from './components/DataAnalysis';
import { DataCatalog } from './components/DataCatalog';
import { DataQuality } from './components/DataQuality';
import ErrorBoundary from './components/ErrorBoundary';
import { logger } from './utils/logger';
import { TabId, ThemeMode, User } from './types';

interface AppState {
  activeTab: TabId;
  isDarkMode: boolean;
  user: User | null;
  isLoading: boolean;
  error: Error | null;
}

export default function App() {
  // Initialize state with proper types
  const [state, setState] = useState<AppState>(() => ({
    activeTab: 'dashboard',
    isDarkMode: true,
    user: null,
    isLoading: true,
    error: null,
  }));

  // Stable handlers that don't depend on state values
  const handleTabChange = useCallback((tab: TabId) => {
    setState(prev => {
      logger.info('Tab changed', { from: prev.activeTab, to: tab }, { component: 'App' });
      return { ...prev, activeTab: tab };
    });
  }, []);

  const handleThemeToggle = useCallback(() => {
    setState(prev => {
      const newTheme: ThemeMode = prev.isDarkMode ? 'light' : 'dark';
      logger.info('Theme toggled', { 
        from: prev.isDarkMode ? 'dark' : 'light', 
        to: newTheme 
      }, { component: 'App' });
      
      // Update DOM
      if (newTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      
      // Persist theme preference
      try {
        localStorage.setItem('theme', newTheme);
      } catch (error) {
        logger.warn('Failed to save theme preference', { 
          error: error instanceof Error ? error.message : 'Unknown error' 
        }, { component: 'App' });
      }
      
      return { ...prev, isDarkMode: !prev.isDarkMode };
    });
  }, []);

  const handleError = useCallback((error: Error, errorInfo: React.ErrorInfo) => {
    logger.error('Application error caught by boundary', {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
    }, { component: 'App' });
    
    setState(prev => ({ ...prev, error }));
  }, []);

  // Initialize application - run only once
  useEffect(() => {
    let isMounted = true;

    const initializeApp = async () => {
      logger.startPerformanceMeasure('App_app_initialization');
      
      try {
        // Enable dark mode by default
        document.documentElement.classList.add('dark');
        
        // Load saved theme preference
        const savedTheme = localStorage.getItem('theme') as ThemeMode | null;
        const isDark = savedTheme === 'dark' || savedTheme === null;
        
        if (savedTheme === 'light') {
          document.documentElement.classList.remove('dark');
        }

        // Load user data (mock for now)
        const mockUser: User = {
          id: 'user_1',
          name: 'Data Analyst',
          email: 'analyst@company.com',
          role: 'Admin',
          permissions: ['read', 'write', 'admin'],
          department: 'Analytics',
          preferences: {
            theme: savedTheme || 'dark',
            sidebarCollapsed: false,
            defaultTimeframe: '7d',
            notifications: {
              email: true,
              inApp: true,
              dataQuality: true,
              systemAlerts: true,
              digest: 'daily',
            },
            dashboard: {
              autoRefresh: true,
              refreshInterval: 30000,
              defaultView: 'dashboard',
              widgets: ['metrics', 'activity', 'charts'],
            },
          },
        };

        // Only update state if component is still mounted
        if (isMounted) {
          setState(prev => ({ 
            ...prev, 
            user: mockUser, 
            isLoading: false,
            isDarkMode: isDark,
          }));

          logger.info('Application initialized successfully', {
            userId: mockUser.id,
            theme: savedTheme || 'dark',
            initialTab: 'dashboard',
          }, { component: 'App' });
        }

      } catch (error) {
        if (isMounted) {
          logger.error('Failed to initialize application', {
            error: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined,
          }, { component: 'App' });
          
          setState(prev => ({ 
            ...prev, 
            error: error instanceof Error ? error : new Error('Unknown initialization error'),
            isLoading: false,
          }));
        }
      } finally {
        logger.endPerformanceMeasure('App_app_initialization', { component: 'App' });
      }
    };

    initializeApp();

    // Cleanup function
    return () => {
      isMounted = false;
    };
  }, []); // Empty dependency array - run only once

  // Update logger context when user changes
  useEffect(() => {
    if (state.user) {
      logger.setContext({
        userId: state.user.id,
        userRole: state.user.role,
        userDepartment: state.user.department,
      });
    }
  }, [state.user]);

  // Memoized layout calculation
  const isFullScreen = useMemo(() => {
    const fullScreenPages: TabId[] = ['dashboard', 'analysis'];
    return fullScreenPages.includes(state.activeTab);
  }, [state.activeTab]);

  // Memoized content renderer with better optimization
  const renderContent = useMemo((): React.ReactNode => {
    logger.debug('Rendering content', { activeTab: state.activeTab }, { component: 'App' });

    switch (state.activeTab) {
      case 'dashboard':
        return (
          <ErrorBoundary context="Home" level="page" onError={handleError}>
            <Home onNavigate={handleTabChange} />
          </ErrorBoundary>
        );
      case 'analysis':
        return (
          <ErrorBoundary context="DataAnalysis" level="page" onError={handleError}>
            <DataAnalysis />
          </ErrorBoundary>
        );
      case 'data':
        return (
          <ErrorBoundary context="DataGrid" level="page" onError={handleError}>
            <DataGrid />
          </ErrorBoundary>
        );
      case 'workflows':
        return (
          <ErrorBoundary context="FlowEditor" level="page" onError={handleError}>
            <FlowEditor />
          </ErrorBoundary>
        );
      case 'code':
        return (
          <ErrorBoundary context="CodeEditor" level="page" onError={handleError}>
            <CodeEditor />
          </ErrorBoundary>
        );
      case 'charts':
        return (
          <ErrorBoundary context="Dashboard" level="page" onError={handleError}>
            <Dashboard />
          </ErrorBoundary>
        );
      case 'files':
        return (
          <ErrorBoundary context="DataCatalog" level="page" onError={handleError}>
            <DataCatalog />
          </ErrorBoundary>
        );
      case 'security':
        return (
          <ErrorBoundary context="DataQuality" level="page" onError={handleError}>
            <DataQuality />
          </ErrorBoundary>
        );
      case 'settings':
        return (
          <ErrorBoundary context="Settings" level="page" onError={handleError}>
            <Settings />
          </ErrorBoundary>
        );
      default:
        logger.warn('Unknown tab accessed', { activeTab: state.activeTab }, { component: 'App' });
        return (
          <ErrorBoundary context="Home" level="page" onError={handleError}>
            <Home onNavigate={handleTabChange} />
          </ErrorBoundary>
        );
    }
  }, [state.activeTab, handleTabChange, handleError]);

  // Loading state
  if (state.isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0b0f] dark flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading application...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (state.error) {
    return (
      <ErrorBoundary context="App" level="page" onError={handleError}>
        <div>Application Error</div>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary 
      context="App" 
      level="page" 
      onError={handleError}
      maxRetries={3}
    >
      <div className="min-h-screen bg-[#0a0b0f] dark">
        <div className="flex h-screen">
          {!isFullScreen && (
            <ErrorBoundary context="Sidebar" level="component" onError={handleError}>
              <Sidebar
                activeTab={state.activeTab}
                onTabChange={handleTabChange}
              />
            </ErrorBoundary>
          )}
          
          <div className="flex-1 flex flex-col overflow-hidden">
            {!isFullScreen && (
              <ErrorBoundary context="Header" level="component" onError={handleError}>
                <Header
                  isDarkMode={state.isDarkMode}
                  onToggleDarkMode={handleThemeToggle}
                />
              </ErrorBoundary>
            )}
            
            <main
              className={`flex-1 overflow-auto transition-colors duration-200 ${
                isFullScreen ? 'bg-[#0a0b0f]' : 'bg-background'
              }`}
            >
              {renderContent}
            </main>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}