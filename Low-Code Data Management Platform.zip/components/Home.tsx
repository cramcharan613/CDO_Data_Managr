import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  BarChart3, 
  Database, 
  GitBranch, 
  Code, 
  Settings, 
  Users, 
  Activity, 
  TrendingUp, 
  Calendar, 
  Bell, 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Share,
  Download,
  RefreshCw,
  Eye,
  Star,
  Heart,
  MessageCircle,
  ArrowRight,
  ChevronRight,
  Zap,
  Shield,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle
} from 'lucide-react';
import { TabId } from '../types';

interface HomeProps {
  onNavigate: (tab: TabId) => void;
}

export function Home({ onNavigate }: HomeProps) {
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const quickActions = [
    {
      id: 'create-workflow',
      title: 'Create Workflow',
      description: 'Build a new data processing pipeline',
      icon: <GitBranch className="w-5 h-5" />,
      action: () => onNavigate('workflows'),
      color: 'blue'
    },
    {
      id: 'import-data',
      title: 'Import Data',
      description: 'Upload and process new datasets',
      icon: <Database className="w-5 h-5" />,
      action: () => onNavigate('data'),
      color: 'green'
    },
    {
      id: 'run-analysis',
      title: 'Run Analysis',
      description: 'Execute comprehensive data analysis',
      icon: <BarChart3 className="w-5 h-5" />,
      action: () => onNavigate('analysis'),
      color: 'purple'
    },
    {
      id: 'code-editor',
      title: 'Code Editor',
      description: 'Write and test custom scripts',
      icon: <Code className="w-5 h-5" />,
      action: () => onNavigate('code'),
      color: 'orange'
    },
    {
      id: 'view-charts',
      title: 'View Charts',
      description: 'Explore data visualizations',
      icon: <TrendingUp className="w-5 h-5" />,
      action: () => onNavigate('charts'),
      color: 'cyan'
    },
    {
      id: 'manage-files',
      title: 'Manage Files',
      description: 'Organize and catalog data files',
      icon: <Search className="w-5 h-5" />,
      action: () => onNavigate('files'),
      color: 'pink'
    }
  ];

  const metrics = [
    {
      title: 'Total Records',
      value: '2.4M',
      change: '+12.3%',
      changeType: 'positive' as const,
      icon: <Database className="w-4 h-4" />
    },
    {
      title: 'Active Workflows',
      value: '342',
      change: '+5.7%',
      changeType: 'positive' as const,
      icon: <GitBranch className="w-4 h-4" />
    },
    {
      title: 'Data Quality',
      value: '98.2%',
      change: '+0.8%',
      changeType: 'positive' as const,
      icon: <Shield className="w-4 h-4" />
    },
    {
      title: 'Processing Speed',
      value: '1.2GB/s',
      change: '-2.1%',
      changeType: 'negative' as const,
      icon: <Zap className="w-4 h-4" />
    }
  ];

  const recentActivity = [
    {
      id: 1,
      title: 'Data Processing Pipeline v2.1',
      description: 'Successfully processed 15,000 records',
      timestamp: '2 minutes ago',
      status: 'completed',
      user: 'John Doe'
    },
    {
      id: 2,
      title: 'Customer Segmentation Analysis',
      description: 'Generated insights from customer data',
      timestamp: '15 minutes ago',
      status: 'completed',
      user: 'Jane Smith'
    },
    {
      id: 3,
      title: 'Sales Data Import',
      description: 'Imported Q4 2024 sales data',
      timestamp: '1 hour ago',
      status: 'running',
      user: 'Mike Johnson'
    },
    {
      id: 4,
      title: 'Custom Validation Script',
      description: 'Updated data validation logic',
      timestamp: '2 hours ago',
      status: 'completed',
      user: 'Sarah Wilson'
    }
  ];

  const systemStatus = [
    { name: 'API Health', status: 'healthy', uptime: '99.9%' },
    { name: 'Database', status: 'healthy', uptime: '99.8%' },
    { name: 'Processing Queue', status: 'warning', uptime: '98.5%' },
    { name: 'Storage', status: 'healthy', uptime: '99.7%' }
  ];

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 2000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'running':
        return <Clock className="w-4 h-4 text-blue-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'text-green-500';
      case 'warning':
        return 'text-yellow-500';
      case 'error':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-semibold text-foreground mb-2">
              Data Management Platform
            </h1>
            <p className="text-muted-foreground">
              Streamline your data workflows with powerful analysis tools and automation
            </p>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Refreshing...' : 'Refresh'}
            </Button>
            <Button onClick={() => onNavigate('settings')}>
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {metrics.map((metric, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="text-muted-foreground">
                    {metric.icon}
                  </div>
                  <div className={`text-sm ${
                    metric.changeType === 'positive' ? 'text-green-500' : 'text-red-500'
                  }`}>
                    {metric.change}
                  </div>
                </div>
                <div className="mt-4">
                  <div className="text-2xl font-bold text-foreground">
                    {metric.value}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {metric.title}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickActions.map((action) => (
            <Card 
              key={action.id}
              className={`cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-105 ${
                selectedCard === action.id ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => {
                setSelectedCard(action.id);
                action.action();
              }}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="text-primary">
                    {action.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground mb-1">
                      {action.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {action.description}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Activity</CardTitle>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm">
                    <Search className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-4 p-3 rounded-lg hover:bg-accent transition-colors">
                    <div className="mt-1">
                      {getStatusIcon(activity.status)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium text-foreground truncate">
                          {activity.title}
                        </h4>
                        <span className="text-xs text-muted-foreground">
                          {activity.timestamp}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {activity.description}
                      </p>
                      <span className="text-xs text-muted-foreground">
                        by {activity.user}
                      </span>
                    </div>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                System Status
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {systemStatus.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-card">
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        {item.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {item.uptime} uptime
                      </div>
                    </div>
                    <Badge 
                      variant={item.status === 'healthy' ? 'default' : 'destructive'}
                      className={getStatusColor(item.status)}
                    >
                      {item.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}