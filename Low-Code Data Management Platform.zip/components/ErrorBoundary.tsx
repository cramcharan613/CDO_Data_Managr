import React, { Component, ReactNode } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { logger } from '../utils/logger';
import { ErrorEvent } from '../types';
import { 
  AlertTriangle, 
  RefreshCw, 
  Home, 
  ChevronDown, 
  ChevronUp,
  Copy,
  Bug,
  Clock,
  User,
  Monitor
} from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
  errorId: string;
  showDetails: boolean;
  retryCount: number;
}

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
  resetOnPropsChange?: boolean;
  maxRetries?: number;
  context?: string;
  level?: 'page' | 'component' | 'section';
}

interface ErrorFallbackProps {
  error: Error;
  errorInfo: React.ErrorInfo;
  errorId: string;
  showDetails: boolean;
  retryCount: number;
  maxRetries: number;
  context?: string;
  level: 'page' | 'component' | 'section';
  onShowDetails: () => void;
  onRetry: () => void;
  onGoHome: () => void;
  onCopyError: () => void;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  private retryTimeoutId: number | null = null;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: '',
      showDetails: false,
      retryCount: 0,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    const errorId = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      hasError: true,
      error,
      errorId,
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    const { onError, context = 'Unknown' } = this.props;
    const { errorId } = this.state;

    // Log error with full context
    const errorEvent: ErrorEvent = {
      type: 'error',
      error,
      errorInfo,
      context,
      timestamp: new Date().toISOString(),
    };

    logger.error('React Error Boundary caught an error', {
      errorId,
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      context,
      props: this.props,
      url: typeof window !== 'undefined' ? window.location.href : 'unknown',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
      timestamp: new Date().toISOString(),
    });

    // Update state with error info
    this.setState({ errorInfo });

    // Call custom error handler
    if (onError) {
      onError(error, errorInfo);
    }

    // Report to monitoring service (if available)
    this.reportError(error, errorInfo, errorId, context);
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps) {
    const { resetOnPropsChange, children } = this.props;
    const { hasError } = this.state;

    if (hasError && resetOnPropsChange && prevProps.children !== children) {
      this.resetError();
    }
  }

  componentWillUnmount() {
    if (this.retryTimeoutId) {
      clearTimeout(this.retryTimeoutId);
    }
  }

  private reportError = async (
    error: Error, 
    errorInfo: React.ErrorInfo, 
    errorId: string, 
    context: string
  ) => {
    try {
      // Get safe environment info
      const getSafeValue = (getter: () => any, fallback: any = 'unknown') => {
        try {
          return getter();
        } catch {
          return fallback;
        }
      };

      const errorReport = {
        errorId,
        message: error.message,
        stack: error.stack,
        componentStack: errorInfo.componentStack,
        context,
        url: getSafeValue(() => window.location.href),
        timestamp: new Date().toISOString(),
        userAgent: getSafeValue(() => navigator.userAgent),
        userId: getSafeValue(() => localStorage.getItem('userId'), 'anonymous'),
        sessionId: getSafeValue(() => sessionStorage.getItem('sessionId'), 'unknown'),
        buildVersion: getSafeValue(() => 
          typeof window !== 'undefined' && (window as any).APP_VERSION, 'unknown'
        ),
      };

      // Mock API call - replace with actual monitoring service
      if (console && console.warn) {
        console.warn('Error reported to monitoring service:', errorReport);
      }
      
      // Store error locally for debugging
      if (typeof localStorage !== 'undefined') {
        try {
          const existingErrors = JSON.parse(localStorage.getItem('errorReports') || '[]');
          existingErrors.push(errorReport);
          
          // Keep only last 50 errors
          if (existingErrors.length > 50) {
            existingErrors.splice(0, existingErrors.length - 50);
          }
          
          localStorage.setItem('errorReports', JSON.stringify(existingErrors));
        } catch (storageError) {
          // localStorage might be full or unavailable
          if (console && console.warn) {
            console.warn('Failed to store error report locally:', storageError);
          }
        }
      }
    } catch (reportingError) {
      logger.error('Failed to report error to monitoring service', {
        originalError: error.message,
        reportingError: reportingError instanceof Error ? reportingError.message : 'Unknown error',
      });
    }
  };

  private resetError = () => {
    if (this.retryTimeoutId) {
      clearTimeout(this.retryTimeoutId);
    }

    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: '',
      showDetails: false,
      retryCount: 0,
    });
  };

  private handleRetry = () => {
    const { maxRetries = 3 } = this.props;
    const { retryCount } = this.state;

    if (retryCount >= maxRetries) {
      logger.warn('Maximum retry attempts reached', { retryCount, maxRetries });
      return;
    }

    logger.info('Retrying after error', { retryCount: retryCount + 1 });

    this.setState({ retryCount: retryCount + 1 });

    // Add delay before retry to prevent immediate re-error
    this.retryTimeoutId = window.setTimeout(() => {
      this.resetError();
    }, 1000 * Math.min(retryCount + 1, 5)); // Exponential backoff, max 5 seconds
  };

  private handleGoHome = () => {
    logger.info('Navigating to home after error');
    
    if (typeof window !== 'undefined') {
      window.location.href = '/';
    }
  };

  private handleShowDetails = () => {
    this.setState(prevState => ({ showDetails: !prevState.showDetails }));
  };

  private handleCopyError = () => {
    const { error, errorInfo, errorId, context } = this.state;
    
    const errorDetails = {
      errorId,
      message: error?.message,
      stack: error?.stack,
      componentStack: errorInfo?.componentStack,
      context,
      timestamp: new Date().toISOString(),
      url: typeof window !== 'undefined' ? window.location.href : 'unknown',
    };

    const errorText = JSON.stringify(errorDetails, null, 2);

    // Try to copy to clipboard
    if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(errorText)
        .then(() => {
          logger.info('Error details copied to clipboard');
          // In a real app, you might show a toast notification here
        })
        .catch(() => {
          logger.error('Failed to copy error details to clipboard');
          // Fallback: show in console
          if (console && console.log) {
            console.log('Error details:', errorText);
          }
        });
    } else {
      // Fallback for older browsers
      if (console && console.log) {
        console.log('Error details (copy manually):', errorText);
      }
    }
  };

  render() {
    const { children, fallback, maxRetries = 3, context, level = 'component' } = this.props;
    const { hasError, error, errorInfo, errorId, showDetails, retryCount } = this.state;

    if (hasError && error) {
      if (fallback) {
        return fallback;
      }

      return (
        <ErrorFallback
          error={error}
          errorInfo={errorInfo!}
          errorId={errorId}
          showDetails={showDetails}
          retryCount={retryCount}
          maxRetries={maxRetries}
          context={context}
          level={level}
          onShowDetails={this.handleShowDetails}
          onRetry={this.handleRetry}
          onGoHome={this.handleGoHome}
          onCopyError={this.handleCopyError}
        />
      );
    }

    return children;
  }
}

// Error Fallback Component
function ErrorFallback({
  error,
  errorInfo,
  errorId,
  showDetails,
  retryCount,
  maxRetries,
  context,
  level,
  onShowDetails,
  onRetry,
  onGoHome,
  onCopyError,
}: ErrorFallbackProps) {
  const isPageLevel = level === 'page';
  const canRetry = retryCount < maxRetries;

  const getErrorSeverity = () => {
    if (error.name === 'TypeError' || error.name === 'ReferenceError') {
      return 'high';
    }
    if (error.message.includes('Network') || error.message.includes('fetch')) {
      return 'medium';
    }
    return 'low';
  };

  const severity = getErrorSeverity();

  const formatTime = () => {
    try {
      return new Date().toLocaleTimeString();
    } catch {
      return new Date().toISOString();
    }
  };

  return (
    <div className={`flex items-center justify-center p-6 ${isPageLevel ? 'min-h-screen bg-background' : 'min-h-64'}`}>
      <Card className={`max-w-2xl w-full bg-destructive/5 border-destructive/20 ${isPageLevel ? 'shadow-xl' : ''}`}>
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-6 h-6 text-destructive" />
            <div className="flex-1">
              <CardTitle className="text-lg text-destructive">
                {isPageLevel ? 'Application Error' : 'Component Error'}
              </CardTitle>
              <CardDescription className="text-destructive/70">
                Something went wrong while {isPageLevel ? 'loading the page' : 'rendering this component'}
              </CardDescription>
            </div>
            <Badge variant="outline" className={`
              ${severity === 'high' ? 'border-red-500 text-red-500' : 
                severity === 'medium' ? 'border-yellow-500 text-yellow-500' : 
                'border-blue-500 text-blue-500'}
            `}>
              {severity.toUpperCase()}
            </Badge>
          </div>
          
          <Alert className="bg-destructive/10 border-destructive/30">
            <Bug className="w-4 h-4" />
            <AlertDescription className="font-mono text-sm">
              {error.message}
            </AlertDescription>
          </Alert>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Error Metadata */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>{formatTime()}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="w-3 h-3" />
              <span>ID: {errorId.slice(-8)}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Monitor className="w-3 h-3" />
              <span>Context: {context || 'Unknown'}</span>
            </div>
            {retryCount > 0 && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <RefreshCw className="w-3 h-3" />
                <span>Retry: {retryCount}/{maxRetries}</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2">
            {canRetry && (
              <Button onClick={onRetry} variant="default" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            )}
            
            <Button onClick={onGoHome} variant="outline" size="sm">
              <Home className="w-4 h-4 mr-2" />
              Go Home
            </Button>
            
            <Button onClick={onCopyError} variant="outline" size="sm">
              <Copy className="w-4 h-4 mr-2" />
              Copy Error
            </Button>
            
            <Button onClick={onShowDetails} variant="ghost" size="sm">
              {showDetails ? <ChevronUp className="w-4 h-4 mr-2" /> : <ChevronDown className="w-4 h-4 mr-2" />}
              {showDetails ? 'Hide' : 'Show'} Details
            </Button>
          </div>

          {/* Error Details */}
          {showDetails && (
            <div className="space-y-3">
              <div>
                <h4 className="font-medium text-sm mb-2">Error Stack:</h4>
                <pre className="text-xs bg-muted/50 p-3 rounded-lg overflow-auto max-h-40 font-mono">
                  {error.stack}
                </pre>
              </div>
              
              {errorInfo.componentStack && (
                <div>
                  <h4 className="font-medium text-sm mb-2">Component Stack:</h4>
                  <pre className="text-xs bg-muted/50 p-3 rounded-lg overflow-auto max-h-40 font-mono">
                    {errorInfo.componentStack}
                  </pre>
                </div>
              )}
            </div>
          )}

          {/* Help Text */}
          <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded-lg">
            <p>
              This error has been automatically reported to our development team. 
              If the problem persists, please contact support with the Error ID above.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default ErrorBoundary;

// Higher-order component for easy wrapping
export function withErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  errorBoundaryProps?: Omit<ErrorBoundaryProps, 'children'>
) {
  const WrappedComponent = (props: P) => (
    <ErrorBoundary {...errorBoundaryProps}>
      <Component {...props} />
    </ErrorBoundary>
  );

  WrappedComponent.displayName = `withErrorBoundary(${Component.displayName || Component.name})`;
  
  return WrappedComponent;
}

// Hook for manually reporting errors
export function useErrorHandler() {
  const reportError = (error: Error, context?: string) => {
    const errorEvent: ErrorEvent = {
      type: 'error',
      error,
      context: context || 'Manual Report',
      timestamp: new Date().toISOString(),
    };

    logger.error('Manual error report', {
      message: error.message,
      stack: error.stack,
      context,
      timestamp: errorEvent.timestamp,
    });

    // In a real app, this would also send to monitoring service
    if (console && console.error) {
      console.error('Manual error report:', errorEvent);
    }
  };

  return { reportError };
}