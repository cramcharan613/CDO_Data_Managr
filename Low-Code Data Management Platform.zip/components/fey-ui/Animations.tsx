import React, { forwardRef, ReactNode, useEffect, useRef, useState } from 'react';
import { cn } from '../ui/utils';

// === ANIMATION WRAPPERS ===
interface AnimationWrapperProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  animation?: 'fade-in' | 'slide-up' | 'slide-down' | 'slide-left' | 'slide-right' | 'scale-in' | 'scale-out' | 'bounce-in' | 'spring-in';
  duration?: 'fast' | 'normal' | 'slow';
  delay?: number;
  trigger?: 'immediate' | 'hover' | 'focus' | 'visible';
  repeat?: boolean;
  onAnimationComplete?: () => void;
}

const AnimationWrapper = forwardRef<HTMLDivElement, AnimationWrapperProps>(
  ({ 
    className, 
    children,
    animation = 'fade-in',
    duration = 'normal',
    delay = 0,
    trigger = 'immediate',
    repeat = false,
    onAnimationComplete,
    ...props 
  }, ref) => {
    const [isAnimating, setIsAnimating] = useState(false);
    const [isVisible, setIsVisible] = useState(false);
    const elementRef = useRef<HTMLDivElement>(null);

    const durationClasses = {
      fast: 'duration-150',
      normal: 'duration-300',
      slow: 'duration-500'
    };

    const animationClasses = {
      'fade-in': 'animate-in fade-in-0',
      'slide-up': 'animate-in slide-in-from-bottom-4',
      'slide-down': 'animate-in slide-in-from-top-4',
      'slide-left': 'animate-in slide-in-from-right-4',
      'slide-right': 'animate-in slide-in-from-left-4',
      'scale-in': 'animate-in zoom-in-95',
      'scale-out': 'animate-out zoom-out-95',
      'bounce-in': 'animate-in zoom-in-95 duration-200',
      'spring-in': 'animate-in zoom-in-95 duration-300'
    };

    useEffect(() => {
      if (trigger === 'visible') {
        const observer = new IntersectionObserver(
          ([entry]) => {
            if (entry.isIntersecting) {
              setIsVisible(true);
              setIsAnimating(true);
            } else if (repeat) {
              setIsVisible(false);
              setIsAnimating(false);
            }
          },
          { threshold: 0.1 }
        );

        if (elementRef.current) {
          observer.observe(elementRef.current);
        }

        return () => observer.disconnect();
      } else if (trigger === 'immediate') {
        setTimeout(() => {
          setIsVisible(true);
          setIsAnimating(true);
        }, delay);
      }
    }, [trigger, delay, repeat]);

    const handleAnimationEnd = () => {
      setIsAnimating(false);
      onAnimationComplete?.();
    };

    const handleMouseEnter = () => {
      if (trigger === 'hover') {
        setIsVisible(true);
        setIsAnimating(true);
      }
    };

    const handleFocus = () => {
      if (trigger === 'focus') {
        setIsVisible(true);
        setIsAnimating(true);
      }
    };

    return (
      <div
        ref={ref}
        className={cn(
          isVisible && animationClasses[animation],
          durationClasses[duration],
          'ease-out',
          className
        )}
        onMouseEnter={handleMouseEnter}
        onFocus={handleFocus}
        onAnimationEnd={handleAnimationEnd}
        style={{ animationDelay: `${delay}ms` }}
        {...props}
      >
        <div ref={elementRef}>
          {children}
        </div>
      </div>
    );
  }
);

AnimationWrapper.displayName = 'AnimationWrapper';

// === STAGGER ANIMATION ===
interface StaggerAnimationProps {
  children: ReactNode[];
  staggerDelay?: number;
  animation?: 'fade-in' | 'slide-up' | 'slide-down' | 'scale-in';
  duration?: 'fast' | 'normal' | 'slow';
  trigger?: 'immediate' | 'visible';
}

const StaggerAnimation = ({ 
  children, 
  staggerDelay = 100, 
  animation = 'fade-in',
  duration = 'normal',
  trigger = 'immediate'
}: StaggerAnimationProps) => {
  return (
    <>
      {React.Children.map(children, (child, index) => (
        <AnimationWrapper
          key={index}
          animation={animation}
          duration={duration}
          delay={index * staggerDelay}
          trigger={trigger}
        >
          {child}
        </AnimationWrapper>
      ))}
    </>
  );
};

// === HOVER LIFT ANIMATION ===
interface HoverLiftProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  liftHeight?: 'sm' | 'md' | 'lg';
  shadowIntensity?: 'low' | 'medium' | 'high';
  duration?: 'fast' | 'normal' | 'slow';
  disabled?: boolean;
}

const HoverLift = forwardRef<HTMLDivElement, HoverLiftProps>(
  ({ 
    className, 
    children,
    liftHeight = 'md',
    shadowIntensity = 'medium',
    duration = 'normal',
    disabled = false,
    ...props 
  }, ref) => {
    const liftClasses = {
      sm: 'hover:-translate-y-1',
      md: 'hover:-translate-y-2',
      lg: 'hover:-translate-y-3'
    };

    const shadowClasses = {
      low: 'hover:shadow-md',
      medium: 'hover:shadow-lg',
      high: 'hover:shadow-xl'
    };

    const durationClasses = {
      fast: 'transition-all duration-150',
      normal: 'transition-all duration-200',
      slow: 'transition-all duration-300'
    };

    return (
      <div
        ref={ref}
        className={cn(
          !disabled && liftClasses[liftHeight],
          !disabled && shadowClasses[shadowIntensity],
          durationClasses[duration],
          'ease-out',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

HoverLift.displayName = 'HoverLift';

// === PULSE ANIMATION ===
interface PulseAnimationProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  intensity?: 'low' | 'medium' | 'high';
  color?: 'primary' | 'success' | 'warning' | 'error';
  duration?: number;
  active?: boolean;
}

const PulseAnimation = forwardRef<HTMLDivElement, PulseAnimationProps>(
  ({ 
    className, 
    children,
    intensity = 'medium',
    color = 'primary',
    duration = 2000,
    active = true,
    ...props 
  }, ref) => {
    const intensityClasses = {
      low: 'animate-pulse opacity-75',
      medium: 'animate-pulse opacity-50',
      high: 'animate-pulse opacity-25'
    };

    const colorClasses = {
      primary: 'ring-primary/20',
      success: 'ring-success/20',
      warning: 'ring-warning/20',
      error: 'ring-error/20'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'relative',
          className
        )}
        {...props}
      >
        {children}
        {active && (
          <div
            className={cn(
              'absolute inset-0 rounded-full ring-4',
              colorClasses[color],
              intensityClasses[intensity]
            )}
            style={{ animationDuration: `${duration}ms` }}
          />
        )}
      </div>
    );
  }
);

PulseAnimation.displayName = 'PulseAnimation';

// === BOUNCE ANIMATION ===
interface BounceAnimationProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  trigger?: 'hover' | 'click' | 'focus' | 'always';
  intensity?: 'low' | 'medium' | 'high';
  duration?: number;
}

const BounceAnimation = forwardRef<HTMLDivElement, BounceAnimationProps>(
  ({ 
    className, 
    children,
    trigger = 'hover',
    intensity = 'medium',
    duration = 300,
    ...props 
  }, ref) => {
    const [isAnimating, setIsAnimating] = useState(false);

    const intensityClasses = {
      low: 'animate-bounce scale-105',
      medium: 'animate-bounce scale-110',
      high: 'animate-bounce scale-125'
    };

    const handleTrigger = () => {
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), duration);
    };

    const eventHandlers = {
      onMouseEnter: trigger === 'hover' ? handleTrigger : undefined,
      onClick: trigger === 'click' ? handleTrigger : undefined,
      onFocus: trigger === 'focus' ? handleTrigger : undefined
    };

    return (
      <div
        ref={ref}
        className={cn(
          'transition-transform duration-200 ease-out',
          (isAnimating || trigger === 'always') && intensityClasses[intensity],
          className
        )}
        {...eventHandlers}
        {...props}
      >
        {children}
      </div>
    );
  }
);

BounceAnimation.displayName = 'BounceAnimation';

// === GLOW ANIMATION ===
interface GlowAnimationProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  color?: 'primary' | 'success' | 'warning' | 'error';
  intensity?: 'low' | 'medium' | 'high';
  trigger?: 'hover' | 'focus' | 'always';
  duration?: number;
}

const GlowAnimation = forwardRef<HTMLDivElement, GlowAnimationProps>(
  ({ 
    className, 
    children,
    color = 'primary',
    intensity = 'medium',
    trigger = 'hover',
    duration = 300,
    ...props 
  }, ref) => {
    const [isGlowing, setIsGlowing] = useState(false);

    const colorClasses = {
      primary: 'shadow-primary/50',
      success: 'shadow-success/50',
      warning: 'shadow-warning/50',
      error: 'shadow-error/50'
    };

    const intensityClasses = {
      low: 'shadow-md',
      medium: 'shadow-lg',
      high: 'shadow-xl'
    };

    const handleMouseEnter = () => {
      if (trigger === 'hover') setIsGlowing(true);
    };

    const handleMouseLeave = () => {
      if (trigger === 'hover') setIsGlowing(false);
    };

    const handleFocus = () => {
      if (trigger === 'focus') setIsGlowing(true);
    };

    const handleBlur = () => {
      if (trigger === 'focus') setIsGlowing(false);
    };

    return (
      <div
        ref={ref}
        className={cn(
          'transition-shadow duration-200 ease-out',
          (isGlowing || trigger === 'always') && intensityClasses[intensity],
          (isGlowing || trigger === 'always') && colorClasses[color],
          className
        )}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onFocus={handleFocus}
        onBlur={handleBlur}
        {...props}
      >
        {children}
      </div>
    );
  }
);

GlowAnimation.displayName = 'GlowAnimation';

// === MORPHING ANIMATION ===
interface MorphingAnimationProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  from: React.CSSProperties;
  to: React.CSSProperties;
  trigger?: 'hover' | 'focus' | 'click' | 'always';
  duration?: number;
  easing?: 'ease-in' | 'ease-out' | 'ease-in-out' | 'linear';
}

const MorphingAnimation = forwardRef<HTMLDivElement, MorphingAnimationProps>(
  ({ 
    className, 
    children,
    from,
    to,
    trigger = 'hover',
    duration = 300,
    easing = 'ease-out',
    ...props 
  }, ref) => {
    const [isTransformed, setIsTransformed] = useState(false);

    const handleTrigger = () => {
      setIsTransformed(true);
    };

    const handleReverse = () => {
      setIsTransformed(false);
    };

    const eventHandlers = {
      onMouseEnter: trigger === 'hover' ? handleTrigger : undefined,
      onMouseLeave: trigger === 'hover' ? handleReverse : undefined,
      onFocus: trigger === 'focus' ? handleTrigger : undefined,
      onBlur: trigger === 'focus' ? handleReverse : undefined,
      onClick: trigger === 'click' ? handleTrigger : undefined
    };

    return (
      <div
        ref={ref}
        className={cn('transition-all', className)}
        style={{
          ...(isTransformed || trigger === 'always' ? to : from),
          transitionDuration: `${duration}ms`,
          transitionTimingFunction: easing
        }}
        {...eventHandlers}
        {...props}
      >
        {children}
      </div>
    );
  }
);

MorphingAnimation.displayName = 'MorphingAnimation';

// === LOADING ANIMATION ===
interface LoadingAnimationProps {
  variant?: 'spinner' | 'dots' | 'pulse' | 'bars' | 'skeleton';
  size?: 'sm' | 'md' | 'lg';
  color?: 'primary' | 'secondary' | 'muted';
  className?: string;
}

const LoadingAnimation = ({ 
  variant = 'spinner', 
  size = 'md',
  color = 'primary',
  className 
}: LoadingAnimationProps) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };

  const colorClasses = {
    primary: 'text-primary',
    secondary: 'text-secondary',
    muted: 'text-muted-foreground'
  };

  if (variant === 'spinner') {
    return (
      <div className={cn(
        'animate-spin rounded-full border-2 border-current border-t-transparent',
        sizeClasses[size],
        colorClasses[color],
        className
      )} />
    );
  }

  if (variant === 'dots') {
    return (
      <div className={cn('flex space-x-1', className)}>
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={cn(
              'rounded-full animate-bounce',
              sizeClasses[size],
              colorClasses[color],
              'bg-current'
            )}
            style={{ animationDelay: `${i * 0.1}s` }}
          />
        ))}
      </div>
    );
  }

  if (variant === 'pulse') {
    return (
      <div className={cn(
        'animate-pulse rounded-full bg-current',
        sizeClasses[size],
        colorClasses[color],
        className
      )} />
    );
  }

  if (variant === 'bars') {
    return (
      <div className={cn('flex space-x-1', className)}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={cn(
              'animate-pulse bg-current',
              'w-1 h-4',
              colorClasses[color]
            )}
            style={{ animationDelay: `${i * 0.1}s` }}
          />
        ))}
      </div>
    );
  }

  if (variant === 'skeleton') {
    return (
      <div className={cn(
        'animate-pulse bg-current rounded opacity-20',
        sizeClasses[size],
        colorClasses[color],
        className
      )} />
    );
  }

  return null;
};

export {
  AnimationWrapper,
  StaggerAnimation,
  HoverLift,
  PulseAnimation,
  BounceAnimation,
  GlowAnimation,
  MorphingAnimation,
  LoadingAnimation
};