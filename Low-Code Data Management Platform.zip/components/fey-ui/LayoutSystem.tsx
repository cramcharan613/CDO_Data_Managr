import React, { forwardRef, ReactNode } from 'react';
import { cn } from '../ui/utils';

// === GRID SYSTEM ===
interface GridProps extends React.HTMLAttributes<HTMLDivElement> {
  cols?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  gap?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  align?: 'start' | 'center' | 'end' | 'stretch';
  justify?: 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly';
  responsive?: {
    sm?: Partial<GridProps>;
    md?: Partial<GridProps>;
    lg?: Partial<GridProps>;
    xl?: Partial<GridProps>;
  };
}

const Grid = forwardRef<HTMLDivElement, GridProps>(
  ({ 
    className, 
    cols = 12, 
    gap = 'md',
    align = 'stretch',
    justify = 'start',
    responsive,
    children,
    ...props 
  }, ref) => {
    const gapClasses = {
      none: 'gap-0',
      sm: 'gap-2',
      md: 'gap-4',
      lg: 'gap-6',
      xl: 'gap-8',
      '2xl': 'gap-12'
    };

    const alignClasses = {
      start: 'items-start',
      center: 'items-center',
      end: 'items-end',
      stretch: 'items-stretch'
    };

    const justifyClasses = {
      start: 'justify-start',
      center: 'justify-center',
      end: 'justify-end',
      between: 'justify-between',
      around: 'justify-around',
      evenly: 'justify-evenly'
    };

    const responsiveClasses = responsive ? Object.entries(responsive).map(([breakpoint, props]) => {
      const prefix = breakpoint === 'sm' ? 'sm:' : breakpoint === 'md' ? 'md:' : breakpoint === 'lg' ? 'lg:' : 'xl:';
      return [
        props.cols && `${prefix}grid-cols-${props.cols}`,
        props.gap && `${prefix}${gapClasses[props.gap]}`,
        props.align && `${prefix}${alignClasses[props.align]}`,
        props.justify && `${prefix}${justifyClasses[props.justify]}`
      ].filter(Boolean).join(' ');
    }).join(' ') : '';

    return (
      <div
        ref={ref}
        className={cn(
          'grid',
          `grid-cols-${cols}`,
          gapClasses[gap],
          alignClasses[align],
          justifyClasses[justify],
          responsiveClasses,
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Grid.displayName = 'Grid';

// === GRID ITEM ===
interface GridItemProps extends React.HTMLAttributes<HTMLDivElement> {
  span?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  start?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  end?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13;
  responsive?: {
    sm?: Partial<GridItemProps>;
    md?: Partial<GridItemProps>;
    lg?: Partial<GridItemProps>;
    xl?: Partial<GridItemProps>;
  };
}

const GridItem = forwardRef<HTMLDivElement, GridItemProps>(
  ({ 
    className, 
    span, 
    start, 
    end, 
    responsive,
    children,
    ...props 
  }, ref) => {
    const responsiveClasses = responsive ? Object.entries(responsive).map(([breakpoint, props]) => {
      const prefix = breakpoint === 'sm' ? 'sm:' : breakpoint === 'md' ? 'md:' : breakpoint === 'lg' ? 'lg:' : 'xl:';
      return [
        props.span && `${prefix}col-span-${props.span}`,
        props.start && `${prefix}col-start-${props.start}`,
        props.end && `${prefix}col-end-${props.end}`
      ].filter(Boolean).join(' ');
    }).join(' ') : '';

    return (
      <div
        ref={ref}
        className={cn(
          span && `col-span-${span}`,
          start && `col-start-${start}`,
          end && `col-end-${end}`,
          responsiveClasses,
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

GridItem.displayName = 'GridItem';

// === FLEX SYSTEM ===
interface FlexProps extends React.HTMLAttributes<HTMLDivElement> {
  direction?: 'row' | 'col' | 'row-reverse' | 'col-reverse';
  wrap?: 'nowrap' | 'wrap' | 'wrap-reverse';
  align?: 'start' | 'center' | 'end' | 'stretch' | 'baseline';
  justify?: 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly';
  gap?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
}

const Flex = forwardRef<HTMLDivElement, FlexProps>(
  ({ 
    className, 
    direction = 'row',
    wrap = 'nowrap',
    align = 'start',
    justify = 'start',
    gap = 'none',
    children,
    ...props 
  }, ref) => {
    const directionClasses = {
      row: 'flex-row',
      col: 'flex-col',
      'row-reverse': 'flex-row-reverse',
      'col-reverse': 'flex-col-reverse'
    };

    const wrapClasses = {
      nowrap: 'flex-nowrap',
      wrap: 'flex-wrap',
      'wrap-reverse': 'flex-wrap-reverse'
    };

    const alignClasses = {
      start: 'items-start',
      center: 'items-center',
      end: 'items-end',
      stretch: 'items-stretch',
      baseline: 'items-baseline'
    };

    const justifyClasses = {
      start: 'justify-start',
      center: 'justify-center',
      end: 'justify-end',
      between: 'justify-between',
      around: 'justify-around',
      evenly: 'justify-evenly'
    };

    const gapClasses = {
      none: 'gap-0',
      sm: 'gap-2',
      md: 'gap-4',
      lg: 'gap-6',
      xl: 'gap-8',
      '2xl': 'gap-12'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'flex',
          directionClasses[direction],
          wrapClasses[wrap],
          alignClasses[align],
          justifyClasses[justify],
          gapClasses[gap],
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Flex.displayName = 'Flex';

// === CONTAINER SYSTEM ===
interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  center?: boolean;
}

const Container = forwardRef<HTMLDivElement, ContainerProps>(
  ({ 
    className, 
    size = 'lg',
    padding = 'md',
    center = true,
    children,
    ...props 
  }, ref) => {
    const sizeClasses = {
      sm: 'max-w-sm',
      md: 'max-w-md',
      lg: 'max-w-4xl',
      xl: 'max-w-6xl',
      '2xl': 'max-w-7xl',
      full: 'max-w-full'
    };

    const paddingClasses = {
      none: 'px-0',
      sm: 'px-4',
      md: 'px-6',
      lg: 'px-8',
      xl: 'px-12',
      '2xl': 'px-16'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'w-full',
          sizeClasses[size],
          paddingClasses[padding],
          center && 'mx-auto',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Container.displayName = 'Container';

// === SECTION SYSTEM ===
interface SectionProps extends React.HTMLAttributes<HTMLElement> {
  spacing?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  background?: 'transparent' | 'primary' | 'secondary' | 'tertiary' | 'elevated';
  border?: boolean;
  glass?: boolean;
}

const Section = forwardRef<HTMLElement, SectionProps>(
  ({ 
    className, 
    spacing = 'lg',
    background = 'transparent',
    border = false,
    glass = false,
    children,
    ...props 
  }, ref) => {
    const spacingClasses = {
      none: 'py-0',
      sm: 'py-8',
      md: 'py-12',
      lg: 'py-16',
      xl: 'py-20',
      '2xl': 'py-24'
    };

    const backgroundClasses = {
      transparent: 'bg-transparent',
      primary: 'fey-surface-primary',
      secondary: 'fey-surface-secondary',
      tertiary: 'fey-surface-tertiary',
      elevated: 'fey-surface-elevated'
    };

    return (
      <section
        ref={ref}
        className={cn(
          'w-full',
          spacingClasses[spacing],
          backgroundClasses[background],
          border && 'border-t fey-border-primary',
          glass && 'fey-glass',
          className
        )}
        {...props}
      >
        {children}
      </section>
    );
  }
);

Section.displayName = 'Section';

// === CARD SYSTEM ===
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'elevated' | 'glass' | 'outlined' | 'minimal';
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  radius?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  interactive?: boolean;
  hoverable?: boolean;
  elevation?: 1 | 2 | 3 | 4 | 5 | 6;
}

const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ 
    className, 
    variant = 'default',
    padding = 'md',
    radius = 'lg',
    interactive = false,
    hoverable = false,
    elevation = 1,
    children,
    ...props 
  }, ref) => {
    const variantClasses = {
      default: 'fey-surface-secondary fey-border-primary border',
      elevated: 'fey-surface-elevated',
      glass: 'fey-glass',
      outlined: 'bg-transparent border-2 fey-border-primary',
      minimal: 'bg-transparent'
    };

    const paddingClasses = {
      none: 'p-0',
      sm: 'p-4',
      md: 'p-6',
      lg: 'p-8',
      xl: 'p-12',
      '2xl': 'p-16'
    };

    const radiusClasses = {
      none: 'rounded-none',
      sm: 'rounded-sm',
      md: 'rounded-md',
      lg: 'rounded-lg',
      xl: 'rounded-xl',
      '2xl': 'rounded-2xl'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'relative',
          variantClasses[variant],
          paddingClasses[padding],
          radiusClasses[radius],
          `fey-elevation-${elevation}`,
          interactive && 'fey-interactive fey-focus-ring cursor-pointer',
          hoverable && 'hover:fey-elevation-3 transition-all duration-200',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Card.displayName = 'Card';

// === NESTED LIST SYSTEM ===
interface NestedListProps extends React.HTMLAttributes<HTMLDivElement> {
  spacing?: 'none' | 'sm' | 'md' | 'lg';
  dividers?: boolean;
  interactive?: boolean;
}

const NestedList = forwardRef<HTMLDivElement, NestedListProps>(
  ({ 
    className, 
    spacing = 'sm',
    dividers = false,
    interactive = false,
    children,
    ...props 
  }, ref) => {
    const spacingClasses = {
      none: 'space-y-0',
      sm: 'space-y-1',
      md: 'space-y-2',
      lg: 'space-y-4'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'w-full',
          spacingClasses[spacing],
          dividers && 'divide-y fey-border-primary',
          interactive && 'fey-interactive',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

NestedList.displayName = 'NestedList';

interface NestedListItemProps extends React.HTMLAttributes<HTMLDivElement> {
  level?: 0 | 1 | 2 | 3 | 4;
  interactive?: boolean;
  selected?: boolean;
  disabled?: boolean;
  icon?: ReactNode;
  actions?: ReactNode;
}

const NestedListItem = forwardRef<HTMLDivElement, NestedListItemProps>(
  ({ 
    className, 
    level = 0,
    interactive = false,
    selected = false,
    disabled = false,
    icon,
    actions,
    children,
    ...props 
  }, ref) => {
    const levelPadding = {
      0: 'pl-0',
      1: 'pl-6',
      2: 'pl-12',
      3: 'pl-18',
      4: 'pl-24'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'flex items-center gap-3 py-2 px-3 rounded-md transition-all duration-150',
          levelPadding[level],
          interactive && 'hover:fey-surface-elevated cursor-pointer fey-focus-ring',
          selected && 'fey-surface-elevated fey-border-focus border-l-2',
          disabled && 'opacity-50 pointer-events-none',
          className
        )}
        {...props}
      >
        {icon && (
          <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center fey-text-secondary">
            {icon}
          </div>
        )}
        <div className="flex-1 min-w-0">
          {children}
        </div>
        {actions && (
          <div className="flex-shrink-0 ml-2">
            {actions}
          </div>
        )}
      </div>
    );
  }
);

NestedListItem.displayName = 'NestedListItem';

// === STACK SYSTEM ===
interface StackProps extends React.HTMLAttributes<HTMLDivElement> {
  spacing?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  align?: 'start' | 'center' | 'end' | 'stretch';
  dividers?: boolean;
}

const Stack = forwardRef<HTMLDivElement, StackProps>(
  ({ 
    className, 
    spacing = 'md',
    align = 'stretch',
    dividers = false,
    children,
    ...props 
  }, ref) => {
    const spacingClasses = {
      none: 'space-y-0',
      sm: 'space-y-2',
      md: 'space-y-4',
      lg: 'space-y-6',
      xl: 'space-y-8',
      '2xl': 'space-y-12'
    };

    const alignClasses = {
      start: 'items-start',
      center: 'items-center',
      end: 'items-end',
      stretch: 'items-stretch'
    };

    return (
      <div
        ref={ref}
        className={cn(
          'flex flex-col',
          spacingClasses[spacing],
          alignClasses[align],
          dividers && 'divide-y fey-border-primary',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Stack.displayName = 'Stack';

export {
  Grid,
  GridItem,
  Flex,
  Container,
  Section,
  Card,
  NestedList,
  NestedListItem,
  Stack
};