import React, { 
  forwardRef, 
  ReactNode, 
  useState, 
  useEffect, 
  useRef,
  createContext,
  useContext
} from 'react';
import { cn } from '../ui/utils';
import { ChevronRight, MoreHorizontal, X } from 'lucide-react';

// === CONTEXTUAL MENU CONTEXT ===
interface ContextualMenuContextType {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  triggerRef: React.RefObject<HTMLElement>;
  position: { x: number; y: number };
  setPosition: (position: { x: number; y: number }) => void;
}

const ContextualMenuContext = createContext<ContextualMenuContextType | null>(null);

const useContextualMenu = () => {
  const context = useContext(ContextualMenuContext);
  if (!context) {
    throw new Error('useContextualMenu must be used within a ContextualMenuProvider');
  }
  return context;
};

// === CONTEXTUAL MENU PROVIDER ===
interface ContextualMenuProviderProps {
  children: ReactNode;
}

const ContextualMenuProvider = ({ children }: ContextualMenuProviderProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const triggerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (triggerRef.current && !triggerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  const contextValue: ContextualMenuContextType = {
    isOpen,
    setIsOpen,
    triggerRef,
    position,
    setPosition
  };

  return (
    <ContextualMenuContext.Provider value={contextValue}>
      {children}
    </ContextualMenuContext.Provider>
  );
};

// === CONTEXTUAL MENU TRIGGER ===
interface ContextualMenuTriggerProps extends React.HTMLAttributes<HTMLElement> {
  asChild?: boolean;
  triggerOn?: 'click' | 'rightClick' | 'hover';
  children: ReactNode;
}

const ContextualMenuTrigger = forwardRef<HTMLElement, ContextualMenuTriggerProps>(
  ({ 
    className, 
    asChild = false, 
    triggerOn = 'click',
    children,
    ...props 
  }, ref) => {
    const { setIsOpen, setPosition, triggerRef } = useContextualMenu();

    const handleTrigger = (event: React.MouseEvent) => {
      event.preventDefault();
      event.stopPropagation();
      
      const rect = event.currentTarget.getBoundingClientRect();
      
      if (triggerOn === 'rightClick') {
        setPosition({
          x: event.clientX,
          y: event.clientY
        });
      } else {
        setPosition({
          x: rect.left,
          y: rect.bottom + 4
        });
      }
      
      setIsOpen(true);
    };

    const handleHover = () => {
      if (triggerOn === 'hover') {
        const rect = triggerRef.current?.getBoundingClientRect();
        if (rect) {
          setPosition({
            x: rect.left,
            y: rect.bottom + 4
          });
          setIsOpen(true);
        }
      }
    };

    const handleMouseLeave = () => {
      if (triggerOn === 'hover') {
        setTimeout(() => setIsOpen(false), 150);
      }
    };

    const eventHandlers = {
      onClick: triggerOn === 'click' ? handleTrigger : undefined,
      onContextMenu: triggerOn === 'rightClick' ? handleTrigger : undefined,
      onMouseEnter: triggerOn === 'hover' ? handleHover : undefined,
      onMouseLeave: triggerOn === 'hover' ? handleMouseLeave : undefined
    };

    if (asChild) {
      return React.cloneElement(children as React.ReactElement, {
        ref: triggerRef,
        ...eventHandlers,
        ...props
      });
    }

    return (
      <button
        ref={triggerRef as React.RefObject<HTMLButtonElement>}
        className={cn(
          'fey-interactive fey-focus-ring rounded-md p-2 fey-text-secondary hover:fey-text-primary',
          className
        )}
        {...eventHandlers}
        {...props}
      >
        {children}
      </button>
    );
  }
);

ContextualMenuTrigger.displayName = 'ContextualMenuTrigger';

// === CONTEXTUAL MENU CONTENT ===
interface ContextualMenuContentProps extends React.HTMLAttributes<HTMLDivElement> {
  align?: 'start' | 'center' | 'end';
  side?: 'top' | 'bottom' | 'left' | 'right';
  sideOffset?: number;
  minWidth?: number;
  maxWidth?: number;
  animate?: boolean;
  children: ReactNode;
}

const ContextualMenuContent = forwardRef<HTMLDivElement, ContextualMenuContentProps>(
  ({ 
    className, 
    align = 'start',
    side = 'bottom',
    sideOffset = 4,
    minWidth = 200,
    maxWidth = 320,
    animate = true,
    children,
    ...props 
  }, ref) => {
    const { isOpen, position } = useContextualMenu();
    const contentRef = useRef<HTMLDivElement>(null);
    const [adjustedPosition, setAdjustedPosition] = useState(position);

    useEffect(() => {
      if (isOpen && contentRef.current) {
        const content = contentRef.current;
        const rect = content.getBoundingClientRect();
        const viewport = {
          width: window.innerWidth,
          height: window.innerHeight
        };

        let adjustedX = position.x;
        let adjustedY = position.y;

        // Adjust horizontal position
        if (adjustedX + rect.width > viewport.width) {
          adjustedX = viewport.width - rect.width - 8;
        }

        // Adjust vertical position
        if (adjustedY + rect.height > viewport.height) {
          adjustedY = position.y - rect.height - sideOffset;
        }

        setAdjustedPosition({ x: adjustedX, y: adjustedY });
      }
    }, [isOpen, position, sideOffset]);

    if (!isOpen) return null;

    return (
      <div
        ref={ref}
        className={cn(
          'fixed z-50 fey-surface-elevated fey-elevation-4 rounded-lg border fey-border-primary',
          'backdrop-blur-md bg-opacity-95',
          animate && 'animate-in fade-in-0 zoom-in-95 duration-200',
          className
        )}
        style={{
          left: adjustedPosition.x,
          top: adjustedPosition.y,
          minWidth,
          maxWidth
        }}
        {...props}
      >
        <div
          ref={contentRef}
          className="py-2 px-1"
        >
          {children}
        </div>
      </div>
    );
  }
);

ContextualMenuContent.displayName = 'ContextualMenuContent';

// === CONTEXTUAL MENU ITEM ===
interface ContextualMenuItemProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: ReactNode;
  shortcut?: string;
  disabled?: boolean;
  destructive?: boolean;
  selected?: boolean;
  children: ReactNode;
}

const ContextualMenuItem = forwardRef<HTMLDivElement, ContextualMenuItemProps>(
  ({ 
    className, 
    icon,
    shortcut,
    disabled = false,
    destructive = false,
    selected = false,
    children,
    onClick,
    ...props 
  }, ref) => {
    const { setIsOpen } = useContextualMenu();

    const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
      if (disabled) return;
      
      onClick?.(event);
      setIsOpen(false);
    };

    return (
      <div
        ref={ref}
        className={cn(
          'flex items-center gap-3 px-3 py-2 mx-1 rounded-md cursor-pointer transition-all duration-150',
          'fey-text-primary hover:fey-surface-tertiary fey-focus-ring',
          selected && 'fey-surface-tertiary',
          disabled && 'opacity-50 pointer-events-none cursor-not-allowed',
          destructive && 'fey-text-error hover:bg-red-500/10',
          className
        )}
        onClick={handleClick}
        {...props}
      >
        {icon && (
          <div className="flex-shrink-0 w-4 h-4 flex items-center justify-center">
            {icon}
          </div>
        )}
        <div className="flex-1 min-w-0 fey-text-sm">
          {children}
        </div>
        {shortcut && (
          <div className="flex-shrink-0 fey-text-xs fey-text-tertiary">
            {shortcut}
          </div>
        )}
      </div>
    );
  }
);

ContextualMenuItem.displayName = 'ContextualMenuItem';

// === CONTEXTUAL MENU SEPARATOR ===
const ContextualMenuSeparator = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'my-1 mx-3 h-px fey-border-primary bg-current opacity-20',
          className
        )}
        {...props}
      />
    );
  }
);

ContextualMenuSeparator.displayName = 'ContextualMenuSeparator';

// === CONTEXTUAL MENU LABEL ===
interface ContextualMenuLabelProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
}

const ContextualMenuLabel = forwardRef<HTMLDivElement, ContextualMenuLabelProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'px-3 py-2 mx-1 fey-text-xs fey-text-tertiary fey-font-medium tracking-wider uppercase',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

ContextualMenuLabel.displayName = 'ContextualMenuLabel';

// === CONTEXTUAL MENU SUB ===
interface ContextualMenuSubProps {
  children: ReactNode;
  trigger: ReactNode;
  icon?: ReactNode;
  disabled?: boolean;
}

const ContextualMenuSub = ({ children, trigger, icon, disabled = false }: ContextualMenuSubProps) => {
  const [isSubOpen, setIsSubOpen] = useState(false);
  const [subPosition, setSubPosition] = useState({ x: 0, y: 0 });
  const triggerRef = useRef<HTMLDivElement>(null);

  const handleMouseEnter = () => {
    if (disabled) return;
    
    const rect = triggerRef.current?.getBoundingClientRect();
    if (rect) {
      setSubPosition({
        x: rect.right + 4,
        y: rect.top
      });
      setIsSubOpen(true);
    }
  };

  const handleMouseLeave = () => {
    setTimeout(() => setIsSubOpen(false), 150);
  };

  return (
    <div
      ref={triggerRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className="relative"
    >
      <div
        className={cn(
          'flex items-center gap-3 px-3 py-2 mx-1 rounded-md cursor-pointer transition-all duration-150',
          'fey-text-primary hover:fey-surface-tertiary fey-focus-ring',
          disabled && 'opacity-50 pointer-events-none cursor-not-allowed'
        )}
      >
        {icon && (
          <div className="flex-shrink-0 w-4 h-4 flex items-center justify-center">
            {icon}
          </div>
        )}
        <div className="flex-1 min-w-0 fey-text-sm">
          {trigger}
        </div>
        <ChevronRight className="w-4 h-4 fey-text-tertiary" />
      </div>
      
      {isSubOpen && (
        <div
          className="fixed z-50 fey-surface-elevated fey-elevation-4 rounded-lg border fey-border-primary backdrop-blur-md bg-opacity-95 animate-in fade-in-0 zoom-in-95 duration-200"
          style={{
            left: subPosition.x,
            top: subPosition.y,
            minWidth: 200
          }}
        >
          <div className="py-2 px-1">
            {children}
          </div>
        </div>
      )}
    </div>
  );
};

// === FLOATING ACTION MENU ===
interface FloatingActionMenuProps {
  children: ReactNode;
  position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
  offset?: number;
  triggerIcon?: ReactNode;
  expanded?: boolean;
  onExpandedChange?: (expanded: boolean) => void;
}

const FloatingActionMenu = ({
  children,
  position = 'bottom-right',
  offset = 24,
  triggerIcon = <MoreHorizontal className="w-5 h-5" />,
  expanded = false,
  onExpandedChange
}: FloatingActionMenuProps) => {
  const [isExpanded, setIsExpanded] = useState(expanded);

  const handleToggle = () => {
    const newExpanded = !isExpanded;
    setIsExpanded(newExpanded);
    onExpandedChange?.(newExpanded);
  };

  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6',
    'top-right': 'top-6 right-6',
    'top-left': 'top-6 left-6'
  };

  return (
    <div className={cn('fixed z-50', positionClasses[position])}>
      <div className="relative">
        {/* Action Items */}
        {isExpanded && (
          <div className="absolute bottom-16 right-0 fey-space-y-2 animate-in fade-in-0 zoom-in-95 duration-200">
            {children}
          </div>
        )}
        
        {/* Main Trigger */}
        <button
          onClick={handleToggle}
          className={cn(
            'w-14 h-14 rounded-full fey-surface-elevated fey-elevation-4 flex items-center justify-center',
            'fey-text-primary hover:fey-elevation-5 fey-interactive fey-focus-ring',
            'transition-all duration-200'
          )}
        >
          {isExpanded ? <X className="w-5 h-5" /> : triggerIcon}
        </button>
      </div>
    </div>
  );
};

// === FLOATING ACTION ITEM ===
interface FloatingActionItemProps extends React.HTMLAttributes<HTMLButtonElement> {
  icon: ReactNode;
  label?: string;
  variant?: 'primary' | 'secondary' | 'destructive';
}

const FloatingActionItem = forwardRef<HTMLButtonElement, FloatingActionItemProps>(
  ({ 
    className, 
    icon, 
    label,
    variant = 'secondary',
    ...props 
  }, ref) => {
    const variantClasses = {
      primary: 'bg-primary text-primary-foreground hover:bg-primary/90',
      secondary: 'fey-surface-elevated fey-text-primary hover:fey-surface-tertiary',
      destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90'
    };

    return (
      <div className="flex items-center gap-3">
        {label && (
          <div className="fey-surface-elevated fey-elevation-2 px-3 py-1 rounded-md fey-text-sm fey-text-primary whitespace-nowrap">
            {label}
          </div>
        )}
        <button
          ref={ref}
          className={cn(
            'w-12 h-12 rounded-full flex items-center justify-center fey-elevation-3',
            'fey-interactive fey-focus-ring transition-all duration-200',
            variantClasses[variant],
            className
          )}
          {...props}
        >
          {icon}
        </button>
      </div>
    );
  }
);

FloatingActionItem.displayName = 'FloatingActionItem';

export {
  ContextualMenuProvider,
  ContextualMenuTrigger,
  ContextualMenuContent,
  ContextualMenuItem,
  ContextualMenuSeparator,
  ContextualMenuLabel,
  ContextualMenuSub,
  FloatingActionMenu,
  FloatingActionItem
};