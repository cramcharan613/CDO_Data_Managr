import { LogEvent } from '../types';
import { useMemo } from 'react';

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LoggerConfig {
  level: LogLevel;
  enableConsole: boolean;
  enableRemote: boolean;
  enableStorage: boolean;
  remoteEndpoint?: string;
  maxStorageEntries: number;
  enableContextCapture: boolean;
  enablePerformanceMetrics: boolean;
}

interface LogContext {
  userId?: string;
  sessionId?: string;
  component?: string;
  action?: string;
  requestId?: string;
  url?: string;
  userAgent?: string;
  timestamp?: string;
  [key: string]: any;
}

interface PerformanceMetric {
  name: string;
  duration: number;
  startTime: number;
  endTime: number;
  context?: LogContext;
}

// Environment detection utilities
const getEnvironment = (): 'development' | 'production' | 'test' => {
  // Check if we're in a browser environment
  if (typeof window !== 'undefined') {
    // Browser environment - check for development indicators
    if (window.location.hostname === 'localhost' || 
        window.location.hostname === '127.0.0.1' || 
        window.location.hostname.includes('dev') ||
        window.location.port !== '') {
      return 'development';
    }
    return 'production';
  }
  
  // Node.js environment
  if (typeof process !== 'undefined' && process.env) {
    return (process.env.NODE_ENV as any) || 'production';
  }
  
  // Fallback
  return 'production';
};

const getEnvVar = (key: string, defaultValue?: string): string | undefined => {
  // Check if process is available (Node.js environment)
  if (typeof process !== 'undefined' && process.env) {
    return process.env[key] || defaultValue;
  }
  
  // Browser environment - check for global variables or meta tags
  if (typeof window !== 'undefined') {
    // Check for meta tags (build-time environment variables)
    const metaElement = document.querySelector(`meta[name="${key}"]`);
    if (metaElement) {
      return metaElement.getAttribute('content') || defaultValue;
    }
    
    // Check for global variables
    const globalVar = (window as any)[key];
    if (globalVar) {
      return globalVar;
    }
  }
  
  return defaultValue;
};

class Logger {
  private config: LoggerConfig;
  private context: LogContext = {};
  private performanceMarks: Map<string, number> = new Map();
  private environment: string;

  constructor(config: Partial<LoggerConfig> = {}) {
    this.environment = getEnvironment();
    
    this.config = {
      level: this.environment === 'development' ? 'debug' : 'info',
      enableConsole: true,
      enableRemote: this.environment === 'production',
      enableStorage: true,
      remoteEndpoint: getEnvVar('REACT_APP_LOG_ENDPOINT'),
      maxStorageEntries: 1000,
      enableContextCapture: true,
      enablePerformanceMetrics: true,
      ...config,
    };

    this.initializeContext();
    this.setupGlobalErrorHandlers();
  }

  private initializeContext() {
    if (typeof window !== 'undefined') {
      this.context = {
        sessionId: this.getOrCreateSessionId(),
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
      };

      // Listen for navigation changes
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;

      history.pushState = (...args) => {
        originalPushState.apply(history, args);
        this.updateContext({ url: window.location.href });
      };

      history.replaceState = (...args) => {
        originalReplaceState.apply(history, args);
        this.updateContext({ url: window.location.href });
      };

      window.addEventListener('popstate', () => {
        this.updateContext({ url: window.location.href });
      });
    }
  }

  private getOrCreateSessionId(): string {
    if (typeof sessionStorage === 'undefined') {
      return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    let sessionId = sessionStorage.getItem('sessionId');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      try {
        sessionStorage.setItem('sessionId', sessionId);
      } catch (error) {
        // Handle storage quota exceeded or other storage errors
        console.warn('Failed to set sessionId in sessionStorage:', error);
      }
    }
    return sessionId;
  }

  private setupGlobalErrorHandlers() {
    if (typeof window !== 'undefined') {
      // Unhandled JavaScript errors
      window.addEventListener('error', (event) => {
        this.error('Unhandled JavaScript error', {
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          stack: event.error?.stack,
          type: 'javascript_error',
        });
      });

      // Unhandled Promise rejections
      window.addEventListener('unhandledrejection', (event) => {
        this.error('Unhandled Promise rejection', {
          reason: event.reason,
          promise: event.promise,
          type: 'promise_rejection',
        });
      });

      // Resource loading errors
      window.addEventListener('error', (event) => {
        if (event.target !== window) {
          this.error('Resource loading error', {
            type: 'resource_error',
            elementType: (event.target as any)?.tagName,
            source: (event.target as any)?.src || (event.target as any)?.href,
            message: 'Failed to load resource',
          });
        }
      }, true);
    }
  }

  setContext(context: LogContext) {
    this.context = { ...this.context, ...context };
  }

  updateContext(updates: Partial<LogContext>) {
    this.context = { ...this.context, ...updates };
  }

  clearContext() {
    this.context = {};
    this.initializeContext();
  }

  private shouldLog(level: LogLevel): boolean {
    const levels: LogLevel[] = ['debug', 'info', 'warn', 'error'];
    const currentLevelIndex = levels.indexOf(this.config.level);
    const logLevelIndex = levels.indexOf(level);
    return logLevelIndex >= currentLevelIndex;
  }

  private createLogEvent(
    level: LogLevel,
    message: string,
    data?: Record<string, any>,
    context?: LogContext
  ): LogEvent {
    const requestId = this.generateRequestId();
    
    return {
      level,
      message,
      context: context?.component || this.context.component || 'Unknown',
      data: {
        ...data,
        ...this.context,
        ...context,
        environment: this.environment,
      },
      timestamp: new Date().toISOString(),
      requestId,
    };
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private formatConsoleMessage(logEvent: LogEvent): any[] {
    const { level, message, data, timestamp, requestId } = logEvent;
    const timeStr = new Date(timestamp).toLocaleTimeString();
    
    const prefix = `[${timeStr}] [${level.toUpperCase()}] [${requestId.slice(-8)}]`;
    
    if (data && Object.keys(data).length > 0) {
      return [
        `%c${prefix}%c ${message}`,
        'color: #666; font-weight: bold;',
        'color: inherit;',
        data
      ];
    } else {
      return [
        `%c${prefix}%c ${message}`,
        'color: #666; font-weight: bold;',
        'color: inherit;'
      ];
    }
  }

  private logToConsole(logEvent: LogEvent) {
    if (!this.config.enableConsole || typeof console === 'undefined') return;

    const consoleArgs = this.formatConsoleMessage(logEvent);
    
    switch (logEvent.level) {
      case 'debug':
        if (console.debug) {
          console.debug(...consoleArgs);
        } else {
          console.log(...consoleArgs);
        }
        break;
      case 'info':
        if (console.info) {
          console.info(...consoleArgs);
        } else {
          console.log(...consoleArgs);
        }
        break;
      case 'warn':
        if (console.warn) {
          console.warn(...consoleArgs);
        } else {
          console.log(...consoleArgs);
        }
        break;
      case 'error':
        if (console.error) {
          console.error(...consoleArgs);
        } else {
          console.log(...consoleArgs);
        }
        break;
    }
  }

  private logToStorage(logEvent: LogEvent) {
    if (!this.config.enableStorage || typeof localStorage === 'undefined') return;

    try {
      const storageKey = 'app_logs';
      const existingLogs = JSON.parse(localStorage.getItem(storageKey) || '[]');
      
      existingLogs.push(logEvent);
      
      // Keep only the most recent entries
      if (existingLogs.length > this.config.maxStorageEntries) {
        existingLogs.splice(0, existingLogs.length - this.config.maxStorageEntries);
      }
      
      localStorage.setItem(storageKey, JSON.stringify(existingLogs));
    } catch (error) {
      // Handle storage quota exceeded or other storage errors
      if (console && console.warn) {
        console.warn('Failed to save log to localStorage:', error);
      }
    }
  }

  private async logToRemote(logEvent: LogEvent) {
    if (!this.config.enableRemote || !this.config.remoteEndpoint || typeof fetch === 'undefined') {
      return;
    }

    try {
      const response = await fetch(this.config.remoteEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(logEvent),
      });

      if (!response.ok && console && console.warn) {
        console.warn('Failed to send log to remote endpoint:', response.statusText);
      }
    } catch (error) {
      if (console && console.warn) {
        console.warn('Error sending log to remote endpoint:', error);
      }
    }
  }

  private log(
    level: LogLevel,
    message: string,
    data?: Record<string, any>,
    context?: LogContext
  ) {
    if (!this.shouldLog(level)) return;

    const logEvent = this.createLogEvent(level, message, data, context);

    // Log to various outputs
    this.logToConsole(logEvent);
    this.logToStorage(logEvent);
    
    if (this.config.enableRemote) {
      this.logToRemote(logEvent).catch(error => {
        if (console && console.warn) {
          console.warn('Remote logging failed:', error);
        }
      });
    }

    // For errors, also capture additional debugging info
    if (level === 'error' && this.config.enableContextCapture) {
      this.captureErrorContext(logEvent);
    }
  }

  private captureErrorContext(logEvent: LogEvent) {
    if (typeof window === 'undefined') return;

    try {
      const errorContext: Record<string, any> = {
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight,
        },
        screen: {
          width: screen.width,
          height: screen.height,
        },
        localStorage: this.getStorageUsage(),
      };

      // Add performance memory info if available
      if (typeof performance !== 'undefined' && (performance as any).memory) {
        errorContext.memory = {
          usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
          totalJSHeapSize: (performance as any).memory.totalJSHeapSize,
          jsHeapSizeLimit: (performance as any).memory.jsHeapSizeLimit,
        };
      }

      // Add connection info if available
      if (typeof navigator !== 'undefined' && (navigator as any).connection) {
        errorContext.connection = {
          effectiveType: (navigator as any).connection.effectiveType,
          downlink: (navigator as any).connection.downlink,
          rtt: (navigator as any).connection.rtt,
        };
      }

      this.logToStorage({
        ...logEvent,
        data: {
          ...logEvent.data,
          errorContext,
        },
      });
    } catch (error) {
      if (console && console.warn) {
        console.warn('Failed to capture error context:', error);
      }
    }
  }

  private getStorageUsage(): { used: number; available: number } {
    if (typeof localStorage === 'undefined') {
      return { used: 0, available: 0 };
    }

    try {
      let used = 0;
      for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          used += localStorage.getItem(key)?.length || 0;
        }
      }
      
      return {
        used,
        available: 5 * 1024 * 1024 - used, // Assume 5MB limit
      };
    } catch {
      return { used: 0, available: 0 };
    }
  }

  // Public logging methods
  debug(message: string, data?: Record<string, any>, context?: LogContext) {
    this.log('debug', message, data, context);
  }

  info(message: string, data?: Record<string, any>, context?: LogContext) {
    this.log('info', message, data, context);
  }

  warn(message: string, data?: Record<string, any>, context?: LogContext) {
    this.log('warn', message, data, context);
  }

  error(message: string, data?: Record<string, any>, context?: LogContext) {
    this.log('error', message, data, context);
  }

  // Performance monitoring
  startPerformanceMeasure(name: string) {
    if (!this.config.enablePerformanceMetrics || typeof performance === 'undefined') {
      return;
    }
    
    this.performanceMarks.set(name, performance.now());
    
    if (performance.mark) {
      try {
        performance.mark(`${name}_start`);
      } catch (error) {
        // Performance API may not be fully available
        if (console && console.warn) {
          console.warn('Failed to create performance mark:', error);
        }
      }
    }
  }

  endPerformanceMeasure(name: string, context?: LogContext): PerformanceMetric | null {
    if (!this.config.enablePerformanceMetrics || typeof performance === 'undefined') {
      return null;
    }
    
    const startTime = this.performanceMarks.get(name);
    if (!startTime) {
      this.warn('Performance measure ended without start', { name });
      return null;
    }

    const endTime = performance.now();
    const duration = endTime - startTime;

    if (performance.mark && performance.measure) {
      try {
        performance.mark(`${name}_end`);
        performance.measure(name, `${name}_start`, `${name}_end`);
      } catch (error) {
        // Performance API may not be fully available
        if (console && console.warn) {
          console.warn('Failed to create performance measure:', error);
        }
      }
    }

    const metric: PerformanceMetric = {
      name,
      duration,
      startTime,
      endTime,
      context,
    };

    this.info('Performance measure completed', metric);
    this.performanceMarks.delete(name);

    return metric;
  }

  // Utility methods
  getLogs(): LogEvent[] {
    if (typeof localStorage === 'undefined') return [];
    
    try {
      return JSON.parse(localStorage.getItem('app_logs') || '[]');
    } catch {
      return [];
    }
  }

  clearLogs() {
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem('app_logs');
      } catch (error) {
        if (console && console.warn) {
          console.warn('Failed to clear logs:', error);
        }
      }
    }
    this.info('Logs cleared');
  }

  exportLogs(): string {
    const logs = this.getLogs();
    return JSON.stringify(logs, null, 2);
  }

  // Configuration methods
  setLogLevel(level: LogLevel) {
    this.config.level = level;
    this.info('Log level changed', { newLevel: level });
  }

  getConfig(): LoggerConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<LoggerConfig>) {
    this.config = { ...this.config, ...updates };
    this.info('Logger configuration updated', { updates });
  }

  // Get environment info
  getEnvironment(): string {
    return this.environment;
  }
}

// Create default logger instance
export const logger = new Logger({
  level: getEnvironment() === 'development' ? 'debug' : 'info',
  enableConsole: true,
  enableRemote: getEnvironment() === 'production',
  enableStorage: true,
  remoteEndpoint: getEnvVar('REACT_APP_LOG_ENDPOINT'),
  maxStorageEntries: 1000,
  enableContextCapture: true,
  enablePerformanceMetrics: true,
});

// React hook for using logger with component context - now properly memoized
export function useLogger(componentName?: string) {
  const loggerWithContext = useMemo(() => ({
    debug: (message: string, data?: Record<string, any>) => 
      logger.debug(message, data, { component: componentName }),
    info: (message: string, data?: Record<string, any>) => 
      logger.info(message, data, { component: componentName }),
    warn: (message: string, data?: Record<string, any>) => 
      logger.warn(message, data, { component: componentName }),
    error: (message: string, data?: Record<string, any>) => 
      logger.error(message, data, { component: componentName }),
    startPerformance: (name: string) => 
      logger.startPerformanceMeasure(`${componentName}_${name}`),
    endPerformance: (name: string) => 
      logger.endPerformanceMeasure(`${componentName}_${name}`, { component: componentName }),
  }), [componentName]);

  return loggerWithContext;
}

// Performance monitoring decorators
export function measurePerformance(name?: string) {
  return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const original = descriptor.value;
    const measureName = name || `${target.constructor.name}_${propertyKey}`;

    descriptor.value = function (...args: any[]) {
      logger.startPerformanceMeasure(measureName);
      
      try {
        const result = original.apply(this, args);
        
        if (result instanceof Promise) {
          return result.finally(() => {
            logger.endPerformanceMeasure(measureName);
          });
        } else {
          logger.endPerformanceMeasure(measureName);
          return result;
        }
      } catch (error) {
        logger.endPerformanceMeasure(measureName);
        throw error;
      }
    };

    return descriptor;
  };
}

export default logger;