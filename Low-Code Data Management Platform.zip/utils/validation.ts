import { TabId, DataObject, User, ApiResponse, isValidTabId, isDataObject, isApiError } from '../types';
import { logger } from './logger';

// Validation error class
export class ValidationError extends Error {
  constructor(
    message: string,
    public field?: string,
    public value?: any,
    public code?: string
  ) {
    super(message);
    this.name = 'ValidationError';
  }
}

// Type guard utilities
export const typeGuards = {
  isString: (value: unknown): value is string => typeof value === 'string',
  
  isNumber: (value: unknown): value is number => 
    typeof value === 'number' && !isNaN(value),
  
  isBoolean: (value: unknown): value is boolean => typeof value === 'boolean',
  
  isObject: (value: unknown): value is object => 
    value !== null && typeof value === 'object',
  
  isArray: (value: unknown): value is unknown[] => Array.isArray(value),
  
  isNonEmptyString: (value: unknown): value is string => 
    typeof value === 'string' && value.trim().length > 0,
  
  isValidEmail: (value: unknown): value is string => {
    if (typeof value !== 'string') return false;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  },
  
  isValidUrl: (value: unknown): value is string => {
    if (typeof value !== 'string') return false;
    try {
      new URL(value);
      return true;
    } catch {
      return false;
    }
  },
  
  isPositiveNumber: (value: unknown): value is number => 
    typeof value === 'number' && value > 0,
  
  isNonNegativeNumber: (value: unknown): value is number => 
    typeof value === 'number' && value >= 0,
  
  isValidTabId,
  isDataObject,
  isApiError,
};

// Validation schema types
interface ValidationRule {
  required?: boolean;
  type?: 'string' | 'number' | 'boolean' | 'object' | 'array';
  min?: number;
  max?: number;
  pattern?: RegExp;
  custom?: (value: any) => boolean | string;
  sanitize?: (value: any) => any;
}

interface ValidationSchema {
  [key: string]: ValidationRule;
}

// Sanitization utilities
export const sanitizers = {
  trimString: (value: string): string => value.trim(),
  
  toLowerCase: (value: string): string => value.toLowerCase(),
  
  toUpperCase: (value: string): string => value.toUpperCase(),
  
  removeHtml: (value: string): string => 
    value.replace(/<[^>]*>/g, ''),
  
  escapeHtml: (value: string): string =>
    value
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;'),
  
  normalizeWhitespace: (value: string): string =>
    value.replace(/\s+/g, ' ').trim(),
  
  removeNonPrintable: (value: string): string =>
    value.replace(/[\x00-\x1F\x7F-\x9F]/g, ''),
  
  limitLength: (maxLength: number) => (value: string): string =>
    value.length > maxLength ? value.substring(0, maxLength) : value,
  
  sanitizeNumber: (value: any): number | null => {
    const num = Number(value);
    return isNaN(num) ? null : num;
  },
  
  sanitizeBoolean: (value: any): boolean => {
    if (typeof value === 'boolean') return value;
    if (typeof value === 'string') {
      const lower = value.toLowerCase();
      return lower === 'true' || lower === '1' || lower === 'yes';
    }
    return Boolean(value);
  },
};

// Validation functions
export function validateField(
  value: any,
  rule: ValidationRule,
  fieldName: string
): { isValid: boolean; error?: string; sanitizedValue?: any } {
  try {
    // Apply sanitization if specified
    let sanitizedValue = value;
    if (rule.sanitize) {
      sanitizedValue = rule.sanitize(value);
    }

    // Check required
    if (rule.required && (value === undefined || value === null || value === '')) {
      return {
        isValid: false,
        error: `${fieldName} is required`,
      };
    }

    // Skip further validation if value is empty and not required
    if (!rule.required && (value === undefined || value === null || value === '')) {
      return {
        isValid: true,
        sanitizedValue,
      };
    }

    // Type validation
    if (rule.type) {
      switch (rule.type) {
        case 'string':
          if (!typeGuards.isString(sanitizedValue)) {
            return {
              isValid: false,
              error: `${fieldName} must be a string`,
            };
          }
          break;
        case 'number':
          if (!typeGuards.isNumber(sanitizedValue)) {
            return {
              isValid: false,
              error: `${fieldName} must be a number`,
            };
          }
          break;
        case 'boolean':
          if (!typeGuards.isBoolean(sanitizedValue)) {
            return {
              isValid: false,
              error: `${fieldName} must be a boolean`,
            };
          }
          break;
        case 'object':
          if (!typeGuards.isObject(sanitizedValue)) {
            return {
              isValid: false,
              error: `${fieldName} must be an object`,
            };
          }
          break;
        case 'array':
          if (!typeGuards.isArray(sanitizedValue)) {
            return {
              isValid: false,
              error: `${fieldName} must be an array`,
            };
          }
          break;
      }
    }

    // Min/Max validation
    if (rule.min !== undefined) {
      if (rule.type === 'string' && sanitizedValue.length < rule.min) {
        return {
          isValid: false,
          error: `${fieldName} must be at least ${rule.min} characters`,
        };
      }
      if (rule.type === 'number' && sanitizedValue < rule.min) {
        return {
          isValid: false,
          error: `${fieldName} must be at least ${rule.min}`,
        };
      }
      if (rule.type === 'array' && sanitizedValue.length < rule.min) {
        return {
          isValid: false,
          error: `${fieldName} must have at least ${rule.min} items`,
        };
      }
    }

    if (rule.max !== undefined) {
      if (rule.type === 'string' && sanitizedValue.length > rule.max) {
        return {
          isValid: false,
          error: `${fieldName} must be at most ${rule.max} characters`,
        };
      }
      if (rule.type === 'number' && sanitizedValue > rule.max) {
        return {
          isValid: false,
          error: `${fieldName} must be at most ${rule.max}`,
        };
      }
      if (rule.type === 'array' && sanitizedValue.length > rule.max) {
        return {
          isValid: false,
          error: `${fieldName} must have at most ${rule.max} items`,
        };
      }
    }

    // Pattern validation
    if (rule.pattern && rule.type === 'string') {
      if (!rule.pattern.test(sanitizedValue)) {
        return {
          isValid: false,
          error: `${fieldName} format is invalid`,
        };
      }
    }

    // Custom validation
    if (rule.custom) {
      const customResult = rule.custom(sanitizedValue);
      if (customResult !== true) {
        return {
          isValid: false,
          error: typeof customResult === 'string' ? customResult : `${fieldName} is invalid`,
        };
      }
    }

    return {
      isValid: true,
      sanitizedValue,
    };
  } catch (error) {
    logger.error('Validation error', {
      fieldName,
      value,
      rule,
      error: error.message,
    });

    return {
      isValid: false,
      error: `Validation failed for ${fieldName}`,
    };
  }
}

export function validateObject(
  obj: Record<string, any>,
  schema: ValidationSchema
): { isValid: boolean; errors: string[]; sanitizedData: Record<string, any> } {
  const errors: string[] = [];
  const sanitizedData: Record<string, any> = {};

  for (const [fieldName, rule] of Object.entries(schema)) {
    const value = obj[fieldName];
    const result = validateField(value, rule, fieldName);

    if (!result.isValid && result.error) {
      errors.push(result.error);
    } else if (result.sanitizedValue !== undefined) {
      sanitizedData[fieldName] = result.sanitizedValue;
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitizedData,
  };
}

// Predefined validation schemas
export const validationSchemas = {
  user: {
    name: {
      required: true,
      type: 'string' as const,
      min: 1,
      max: 100,
      sanitize: sanitizers.trimString,
    },
    email: {
      required: true,
      type: 'string' as const,
      custom: typeGuards.isValidEmail,
      sanitize: (value: string) => sanitizers.trimString(value).toLowerCase(),
    },
    role: {
      required: true,
      type: 'string' as const,
      min: 1,
      max: 50,
    },
    department: {
      required: true,
      type: 'string' as const,
      min: 1,
      max: 100,
    },
  } as ValidationSchema,

  dataObject: {
    name: {
      required: true,
      type: 'string' as const,
      min: 1,
      max: 255,
      sanitize: sanitizers.trimString,
    },
    description: {
      required: false,
      type: 'string' as const,
      max: 1000,
      sanitize: sanitizers.normalizeWhitespace,
    },
    owner: {
      required: true,
      type: 'string' as const,
      min: 1,
      max: 100,
    },
    size: {
      required: true,
      type: 'string' as const,
      pattern: /^\d+(\.\d+)?\s*(B|KB|MB|GB|TB|PB)$/i,
    },
  } as ValidationSchema,

  searchQuery: {
    query: {
      required: false,
      type: 'string' as const,
      max: 500,
      sanitize: (value: string) => 
        sanitizers.removeHtml(sanitizers.normalizeWhitespace(value)),
    },
    filters: {
      required: false,
      type: 'object' as const,
    },
    sortBy: {
      required: false,
      type: 'string' as const,
      max: 50,
    },
    sortOrder: {
      required: false,
      type: 'string' as const,
      custom: (value: string) => ['asc', 'desc'].includes(value),
    },
  } as ValidationSchema,
};

// API response validation
export function validateApiResponse<T>(
  response: any,
  dataValidator?: (data: any) => data is T
): ApiResponse<T> {
  if (!typeGuards.isObject(response)) {
    throw new ValidationError('Invalid API response format');
  }

  const apiResponse = response as ApiResponse<T>;

  if (!typeGuards.isBoolean(apiResponse.success)) {
    throw new ValidationError('API response missing success field');
  }

  if (!typeGuards.isString(apiResponse.timestamp)) {
    throw new ValidationError('API response missing timestamp');
  }

  if (!typeGuards.isString(apiResponse.requestId)) {
    throw new ValidationError('API response missing requestId');
  }

  if (apiResponse.success) {
    if (dataValidator && apiResponse.data !== undefined && !dataValidator(apiResponse.data)) {
      throw new ValidationError('API response data validation failed');
    }
  } else {
    if (!typeGuards.isString(apiResponse.error)) {
      throw new ValidationError('API error response missing error message');
    }
  }

  return apiResponse;
}

// Input sanitization for form data
export function sanitizeFormData(data: Record<string, any>): Record<string, any> {
  const sanitized: Record<string, any> = {};

  for (const [key, value] of Object.entries(data)) {
    if (typeGuards.isString(value)) {
      sanitized[key] = sanitizers.normalizeWhitespace(
        sanitizers.removeNonPrintable(value)
      );
    } else if (typeGuards.isNumber(value)) {
      sanitized[key] = value;
    } else if (typeGuards.isBoolean(value)) {
      sanitized[key] = value;
    } else if (typeGuards.isArray(value)) {
      sanitized[key] = value.map(item => 
        typeGuards.isString(item) ? sanitizers.normalizeWhitespace(item) : item
      );
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

// Error handling utilities
export function createValidationError(
  message: string,
  field?: string,
  value?: any
): ValidationError {
  const error = new ValidationError(message, field, value);
  
  logger.warn('Validation error created', {
    message,
    field,
    value: typeof value === 'object' ? JSON.stringify(value) : value,
  });

  return error;
}

export function isValidationError(error: unknown): error is ValidationError {
  return error instanceof ValidationError;
}

// Data structure validators
export const validators = {
  tabId: (value: unknown): value is TabId => isValidTabId(value as string),
  
  dataObject: (value: unknown): value is DataObject => isDataObject(value),
  
  user: (value: unknown): value is User => {
    if (!typeGuards.isObject(value)) return false;
    const obj = value as any;
    return (
      typeGuards.isString(obj.id) &&
      typeGuards.isString(obj.name) &&
      typeGuards.isValidEmail(obj.email) &&
      typeGuards.isString(obj.role) &&
      typeGuards.isArray(obj.permissions) &&
      typeGuards.isString(obj.department)
    );
  },
};

export default {
  typeGuards,
  sanitizers,
  validateField,
  validateObject,
  validationSchemas,
  validateApiResponse,
  sanitizeFormData,
  createValidationError,
  isValidationError,
  validators,
};